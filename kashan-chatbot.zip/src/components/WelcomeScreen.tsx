import React from "react";
import { TrendingUp, Code, GraduationCap, Sparkles, Globe, Languages, Compass } from "lucide-react";
import { PRESET_TOPICS, LANGUAGES } from "../data";
import { PresetTopic, LanguageTemplate } from "../types";

interface WelcomeScreenProps {
  onSelectPreset: (prompt: string) => void;
  onSelectLanguage: (lang: LanguageTemplate) => void;
  isDark: boolean;
}

// Map string icon names to Lucide icons statically
const getIcon = (name: string, isDark: boolean) => {
  switch (name) {
    case "TrendingUp":
      return <TrendingUp className={isDark ? "text-amber-400" : "text-amber-600"} size={20} />;
    case "Code":
      return <Code className={isDark ? "text-emerald-400" : "text-emerald-600"} size={20} />;
    case "GraduationCap":
      return <GraduationCap className={isDark ? "text-sky-400" : "text-sky-600"} size={20} />;
    case "Sparkles":
      return <Sparkles className={isDark ? "text-purple-400" : "text-purple-600"} size={20} />;
    case "Globe":
      return <Globe className={isDark ? "text-rose-500" : "text-rose-600"} size={20} />;
    default:
      return <Compass className="text-slate-400" size={20} />;
  }
};

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({
  onSelectPreset,
  onSelectLanguage,
  isDark
}) => {
  return (
    <div className="max-w-3xl mx-auto px-4 py-8 lg:py-12 flex flex-col items-center justify-center min-h-[75vh]">
      {/* Branding Spark */}
      <div className="flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-tr from-rose-500 to-amber-500 shadow-xl shadow-rose-950/10 mb-6 border border-rose-500/10 hover:scale-105 transition-transform duration-300">
        <Sparkles size={28} className="text-white animate-spin-pulse" />
      </div>

      {/* Main Title and Subtitle */}
      <div className="text-center mb-10 max-w-2xl">
        <h1 className={`text-3xl lg:text-5xl font-extrabold font-sans tracking-tight mb-4 animate-fade-in ${
          isDark 
            ? "text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-100 to-rose-400" 
            : "text-slate-900"
        }`}>
          👋 Welcome to Kashan Chatbot
        </h1>
        <p className={`text-sm lg:text-base leading-relaxed font-sans font-medium px-4 ${
          isDark ? "text-slate-300" : "text-slate-600"
        }`}>
          Hello! I am <span className="text-rose-600 font-bold">Kashan Chatbot</span>, your personal AI assistant. I can help with studies, programming, web development, content creation, business ideas, technology, and general knowledge.
        </p>
      </div>

      {/* Language Quick Starters */}
      <div className="w-full mb-10">
        <div className="flex items-center gap-2 mb-4 justify-center">
          <Languages size={15} className="text-rose-500" />
          <h3 className={`text-xs font-bold tracking-wider uppercase font-sans ${
            isDark ? "text-slate-500" : "text-slate-400"
          }`}>
            Apni Bhasha (Language) Chunyein
          </h3>
        </div>
        <div className="flex flex-wrap justify-center gap-2">
          {LANGUAGES.map((lang) => (
            <button
              key={lang.code}
              onClick={() => onSelectLanguage(lang)}
              className={`flex items-center gap-2 py-2 px-4 rounded-full border transition-all cursor-pointer active:scale-95 text-xs font-sans font-semibold ${
                isDark 
                  ? "bg-slate-900 border-slate-800 hover:border-rose-500/55 hover:bg-slate-900/80 text-slate-300" 
                  : "bg-white border-slate-200 shadow-sm hover:border-rose-500 hover:bg-slate-50 text-slate-750"
              }`}
            >
              <span>{lang.flag}</span>
              <span>{lang.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Preset Recommendation Cards */}
      <div className="w-full">
        <div className="flex items-center gap-2 mb-4 justify-center">
          <Compass size={15} className="text-amber-500 animate-spin-slow" />
          <h3 className={`text-xs font-bold tracking-wider uppercase font-sans ${
            isDark ? "text-slate-500" : "text-slate-400"
          }`}>
            Preset Vishay (Recommended Topics)
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {PRESET_TOPICS.map((topic) => (
            <button
              key={topic.id}
              onClick={() => onSelectPreset(topic.prompt)}
              className={`flex items-start gap-4 p-4 rounded-xl border text-left transition-all hover:-translate-y-0.5 pointer-events-auto cursor-pointer focus:outline-none focus:ring-1 focus:ring-rose-500/20 ${
                isDark
                  ? "bg-slate-900/60 border-slate-800/80 hover:border-slate-700/60 hover:bg-slate-900"
                  : "bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/50 shadow-sm"
              }`}
            >
              <div className={`flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center border shadow ${
                isDark ? "bg-slate-950 border-slate-800" : "bg-slate-50 border-slate-200"
              }`}>
                {getIcon(topic.icon, isDark)}
              </div>
              <div className="min-w-0">
                <h4 className={`text-xs font-semibold tracking-wide mb-1 font-sans ${
                  isDark ? "text-white" : "text-slate-800"
                }`}>
                  {topic.title}
                </h4>
                <p className={`text-[11px] line-clamp-2 leading-relaxed font-sans ${
                  isDark ? "text-slate-400" : "text-slate-500"
                }`}>
                  {topic.description}
                </p>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
