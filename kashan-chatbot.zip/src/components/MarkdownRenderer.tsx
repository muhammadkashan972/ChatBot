import React, { useState } from "react";
import Markdown from "react-markdown";
import { Copy, Check } from "lucide-react";

interface MarkdownRendererProps {
  content: string;
}

export const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
  return (
    <div className="markdown-content text-slate-100 leading-relaxed text-sm lg:text-base space-y-4">
      <Markdown
        components={{
          // Render beautiful code blocks
          code({ className, children, ...props }) {
            const match = /language-(\w+)/.exec(className || "");
            const language = match ? match[1] : "code";
            const codeString = String(children).replace(/\n$/, "");

            return !className ? (
              <code className="bg-slate-800 text-amber-300 px-1.5 py-0.5 rounded text-xs font-mono" {...props}>
                {children}
              </code>
            ) : (
              <CodeBlock language={language} code={codeString} />
            );
          },
          // Custom header styling
          h1: ({ children }) => <h1 className="text-xl lg:text-2xl font-bold font-sans text-white mt-5 mb-2 border-b border-slate-800 pb-1">{children}</h1>,
          h2: ({ children }) => <h2 className="text-lg lg:text-xl font-semibold font-sans text-rose-500 mt-4 mb-2">{children}</h2>,
          h3: ({ children }) => <h3 className="text-md lg:text-lg font-medium font-sans text-amber-400 mt-3 mb-1">{children}</h3>,
          // Custom paragraph styling
          p: ({ children }) => <p className="mb-3 text-slate-300 font-sans">{children}</p>,
          // Custom lists styling
          ul: ({ children }) => <ul className="list-disc pl-6 mb-4 space-y-1.5 text-slate-300 font-sans">{children}</ul>,
          ol: ({ children }) => <ol className="list-decimal pl-6 mb-4 space-y-1.5 text-slate-300 font-sans">{children}</ol>,
          // Custom tables styling
          table: ({ children }) => (
            <div className="overflow-x-auto my-4 border border-slate-800 rounded-lg">
              <table className="min-w-full divide-y divide-slate-800 text-sm">{children}</table>
            </div>
          ),
          thead: ({ children }) => <thead className="bg-slate-900/80 text-rose-400 font-sans">{children}</thead>,
          tbody: ({ children }) => <tbody className="divide-y divide-slate-800/60 bg-slate-950/40 text-slate-300 font-sans">{children}</tbody>,
          tr: ({ children }) => <tr className="hover:bg-slate-900/40 transition-colors">{children}</tr>,
          th: ({ children }) => <th className="px-4 py-2.5 text-left font-semibold border-r border-slate-800/80 last:border-r-0">{children}</th>,
          td: ({ children }) => <td className="px-4 py-2.5 border-r border-slate-800/50 last:border-r-0 font-sans">{children}</td>,
          // Blockquotes
          blockquote: ({ children }) => (
            <blockquote className="border-l-4 border-rose-500 bg-slate-900/30 pl-4 py-2 rounded-r my-4 italic text-slate-400">
              {children}
            </blockquote>
          ),
          // Links helper
          a: ({ href, children }) => (
            <a
              href={href}
              target="_blank"
              rel="noopener noreferrer"
              className="text-rose-400 hover:text-rose-350 underline decoration-rose-500/50 hover:decoration-rose-400 transition-colors"
            >
              {children}
            </a>
          )
        }}
      >
        {content}
      </Markdown>
    </div>
  );
};

interface CodeBlockProps {
  language: string;
  code: string;
}

const CodeBlock: React.FC<CodeBlockProps> = ({ language, code }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error("Failed to copy code to clipboard", err);
    }
  };

  return (
    <div className="my-4 border border-slate-800 rounded-lg bg-slate-950 overflow-hidden font-mono shadow-xl">
      {/* Code block header bar */}
      <div className="flex items-center justify-between px-4 py-2 bg-slate-900 border-b border-slate-800 text-xs text-slate-400">
        <span className="capitalize font-medium tracking-wider text-rose-400 font-mono">{language}</span>
        <button
          onClick={handleCopy}
          className="flex items-center gap-1.5 px-2 py-1 rounded bg-slate-950/60 hover:bg-slate-800 text-slate-400 hover:text-rose-400 border border-slate-800/60 active:scale-95 transition-all cursor-pointer font-sans"
          title="Copy to clipboard"
        >
          {copied ? (
            <>
              <Check size={12} className="text-green-400 animate-pulse" />
              <span className="text-green-400 font-semibold">Copied ✓</span>
            </>
          ) : (
            <>
              <Copy size={12} />
              <span>Copy code</span>
            </>
          )}
        </button>
      </div>
      {/* Code body */}
      <div className="p-4 overflow-x-auto text-xs lg:text-sm text-slate-200 leading-relaxed font-mono select-text bg-slate-950">
        <pre className="font-mono">
          <code className="font-mono block whitespace-pre">{code}</code>
        </pre>
      </div>
    </div>
  );
};
