import React, { useState } from "react";
import { MessageSquare, Trash2, Plus, Search, ChevronLeft, ChevronRight, MessageCircleCode, Settings, User } from "lucide-react";
import { ChatSession } from "../types";

interface SidebarProps {
  sessions: ChatSession[];
  currentSessionId: string | null;
  onSelectSession: (id: string) => void;
  onNewChat: () => void;
  onDeleteSession: (id: string, e: React.MouseEvent) => void;
  isOpen: boolean;
  onToggle: () => void;
  isDark: boolean;
  userName: string;
  userAvatar: string;
  onOpenProfile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  sessions,
  currentSessionId,
  onSelectSession,
  onNewChat,
  onDeleteSession,
  isOpen,
  onToggle,
  isDark,
  userName,
  userAvatar,
  onOpenProfile
}) => {
  const [searchQuery, setSearchQuery] = useState("");

  const filteredSessions = sessions.filter((session) =>
    session.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-30 lg:hidden"
          onClick={onToggle}
        />
      )}

      {/* Sidebar Container */}
      <div
        className={`fixed lg:relative inset-y-0 left-0 z-40 flex flex-col w-72 lg:w-80 border-r transition-all duration-300 transform ${
          isOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        } ${
          isDark 
            ? "bg-slate-950 border-slate-800/80 text-slate-100" 
            : "bg-white border-slate-200 text-slate-800"
        }`}
      >
        {/* Header Block */}
        <div className={`flex items-center justify-between px-5 h-16 border-b ${
          isDark ? "border-slate-800/80 bg-slate-950" : "border-slate-200 bg-slate-50"
        }`}>
          <div className="flex items-center gap-2.5">
            <div className="flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-tr from-rose-600 to-amber-500 shadow-md">
              <MessageCircleCode size={19} className="text-white" />
            </div>
            <div>
              <h2 className={`text-sm font-semibold tracking-wide leading-none ${
                isDark ? "text-white" : "text-slate-900"
              }`}>Kashan Chatbot</h2>
              <span className="text-[10px] text-rose-500 font-bold">Smart AI Active</span>
            </div>
          </div>

          <button
            onClick={onToggle}
            className={`lg:hidden p-1.5 rounded-lg border transition-all ${
              isDark 
                ? "bg-slate-900 border-slate-800 text-slate-400 hover:text-white" 
                : "bg-white border-slate-200 text-slate-500 hover:text-slate-800"
            }`}
          >
            <ChevronLeft size={16} />
          </button>
        </div>

        {/* New Chat Actions */}
        <div className="p-4">
          <button
            onClick={onNewChat}
            className="flex items-center justify-center gap-2 w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-500 hover:to-rose-600 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-md active:scale-[0.98] outline-none border border-rose-500/10 cursor-pointer"
          >
            <Plus size={16} />
            <span>Naya Chat Shuru Karein</span>
          </button>
        </div>

        {/* Search Session Filter */}
        <div className="px-4 mb-3">
          <div className="relative">
            <Search size={14} className={`absolute left-3 top-3 ${isDark ? "text-slate-500" : "text-slate-400"}`} />
            <input
              type="text"
              placeholder="Chat ko dhoondein..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={`w-full py-2.5 pl-9 pr-4 border rounded-xl text-xs transition-all focus:outline-none focus:ring-1 focus:ring-rose-500/20 ${
                isDark 
                  ? "bg-slate-900/60 border-slate-800/80 text-slate-300 placeholder-slate-500 focus:border-rose-500/50" 
                  : "bg-slate-50 border-slate-200 text-slate-700 placeholder-slate-400 focus:border-rose-500"
              }`}
            />
          </div>
        </div>

        {/* History List */}
        <div className="flex-1 overflow-y-auto px-2 space-y-1 scrollbar-thin">
          <div className={`px-3 py-1.5 text-[10px] font-bold tracking-wider uppercase ${
            isDark ? "text-slate-500" : "text-slate-400"
          }`}>
            Aapka Chat Itihas ({filteredSessions.length})
          </div>

          {filteredSessions.length === 0 ? (
            <div className="px-4 py-8 text-center text-xs text-slate-400 italic">
              Koi chat nahi mila
            </div>
          ) : (
            filteredSessions.map((session) => {
              const isActive = session.id === currentSessionId;
              return (
                <div
                  key={session.id}
                  onClick={() => onSelectSession(session.id)}
                  className={`group relative flex items-center justify-between px-3 py-2.5 rounded-xl transition-all cursor-pointer select-none border ${
                    isActive
                      ? isDark 
                        ? "bg-slate-900 border-slate-800/80 text-white font-semibold"
                        : "bg-rose-50/50 border-rose-100 text-rose-800 font-semibold"
                      : isDark
                        ? "text-slate-400 hover:bg-slate-900/40 hover:text-slate-200 border-transparent"
                        : "text-slate-600 hover:bg-slate-50 hover:text-slate-900 border-transparent"
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0 flex-1 pr-4">
                    <MessageSquare
                      size={15}
                      className={isActive ? "text-rose-600" : "text-slate-400 group-hover:text-slate-500"}
                    />
                    <span className="truncate text-xs font-sans tracking-wide">
                      {session.title || "Naya Conversation"}
                    </span>
                  </div>

                  <button
                    onClick={(e) => onDeleteSession(session.id, e)}
                    className={`p-1 rounded opacity-0 group-hover:opacity-100 focus:opacity-100 transition-all duration-150 cursor-pointer ${
                      isDark ? "hover:bg-slate-800 text-slate-500 hover:text-red-400" : "hover:bg-slate-100 text-slate-450 hover:text-red-500"
                    }`}
                    title="Delete Chat"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              );
            })
          )}
        </div>

        {/* User Profile Card */}
        <div className={`p-3 border-t mt-auto ${
          isDark ? "border-slate-800/80 bg-slate-950/80" : "border-slate-100 bg-slate-50/80"
        }`}>
          <div 
            onClick={onOpenProfile}
            className={`flex items-center gap-2.5 p-2 rounded-xl transition-all cursor-pointer border ${
              isDark 
                ? "border-slate-900 hover:bg-slate-900/60 hover:border-slate-800" 
                : "border-slate-200/50 hover:bg-white hover:border-slate-300 shadow-sm"
            }`}
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-rose-500/20 to-amber-500/25 border border-rose-500/20 flex items-center justify-center text-lg shadow-sm">
              {userAvatar || "👨‍💻"}
            </div>
            <div className="min-w-0 flex-1">
              <h4 className={`text-xs font-bold font-sans tracking-wide truncate ${
                isDark ? "text-slate-200" : "text-slate-800"
              }`}>{userName || "User Profile"}</h4>
              <p className="text-[10px] text-slate-500 font-medium">Click to configure Profile</p>
            </div>
            <Settings size={14} className={isDark ? "text-slate-500" : "text-slate-400"} />
          </div>
        </div>

        {/* Minimal Footer */}
        <div className={`p-4 border-t text-[11px] leading-relaxed font-sans ${
          isDark ? "border-slate-800/80 bg-slate-950 text-slate-500" : "border-slate-100 bg-slate-50 text-slate-400"
        }`}>
          <div className="flex items-center gap-2 justify-between">
            <span className="font-semibold">Conversations:</span>
            <span className="font-mono text-xs font-bold text-rose-500">{sessions.length}</span>
          </div>
        </div>
      </div>
    </>
  );
};
