import { PresetTopic, LanguageTemplate } from "./types";

export const PRESET_TOPICS: PresetTopic[] = [
  {
    id: "preset-software",
    category: "software",
    title: "Programming & Web Dev",
    description: "Write, debug, refactor code, and learn dynamic web frameworks.",
    prompt: "I want to build a modern full-stack web application. Can you show me a step-by-step roadmap to learn React, Node.js, and Express, along with a clean code repository folder structure?",
    icon: "Code"
  },
  {
    id: "preset-business",
    category: "business",
    title: "Business & Startup Ideas",
    description: "Brainstorm highly profitable and innovative modern online business models.",
    prompt: "Please brainstorm 5 highly profitable modern online business ideas that can be started with minimal budget, detailing the monetization model and target audience for each.",
    icon: "TrendingUp"
  },
  {
    id: "preset-writing",
    category: "writing",
    title: "Content & Copywriting",
    description: "Craft premium articles, clean newsletters, blogs, and marketing scripts.",
    prompt: "Can you help me write an engaging, professional blog post outline and introduction about the 'Future of Artificial Intelligence in Education'? Keep the tone warm yet scientific.",
    icon: "Sparkles"
  },
  {
    id: "preset-study",
    category: "study",
    title: "Studies & Academics",
    description: "Solve complex calculations, explain complex science concepts, and learn.",
    prompt: "Can you act as an interactive academic tutor for science? Explain the concept of quantum computing in extremely simple terms, using an easy-to-understand analogy.",
    icon: "GraduationCap"
  },
  {
    id: "preset-history",
    category: "history",
    title: "History & World Geography",
    description: "Durable history of subcontinents, dynasties, nations, and world landmarks.",
    prompt: "Mujhe sub-continent (South Asia) ke itihaas (history) ke upar ek detailed overview research do, focusing on important dynasties and historical turns.",
    icon: "Globe"
  }
];

export const LANGUAGES: LanguageTemplate[] = [
  { name: "Urdu (اردو)", code: "ur", flag: "🇵🇰", sampleGreeting: "مجھ سے اردو میں کچھ بھی پوچھیں" },
  { name: "Hindi (हिंदी)", code: "hi", flag: "🇮🇳", sampleGreeting: "मुझसे हिंदी में संवाद करें" },
  { name: "English", code: "en", flag: "🇺🇸", sampleGreeting: "English query playground" },
  { name: "Spanish (Español)", code: "es", flag: "🇪🇸", sampleGreeting: "Pregúntame en español" },
  { name: "Arabic (العربية)", code: "ar", flag: "🇸🇦", sampleGreeting: "اسألني باللغة العربية" },
  { name: "French (Français)", code: "fr", flag: "🇫🇷", sampleGreeting: "Discutons en français" },
  { name: "German (Deutsch)", code: "de", flag: "🇩🇪", sampleGreeting: "Fragen Sie auf Deutsch" },
  { name: "Roman Urdu/Hindi", code: "ur-Latn", flag: "✏️", sampleGreeting: "Roman Urdu ya Hindi me chat karein" }
];
