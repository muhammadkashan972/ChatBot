export interface Attachment {
  name: string;
  type: "image" | "document" | "video";
  mimeType: string;
  base64?: string;
  size?: string;
}

export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
  attachment?: Attachment;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  createdAt: string;
}

export interface PresetTopic {
  id: string;
  category: string;
  title: string;
  description: string;
  prompt: string;
  icon: string;
}

export interface LanguageTemplate {
  name: string;
  code: string;
  flag: string;
  sampleGreeting: string;
}
