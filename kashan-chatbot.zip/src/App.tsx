import React, { useState, useEffect, useRef } from "react";
import { 
  Send, 
  Volume2, 
  VolumeX, 
  Menu, 
  RefreshCw, 
  Bot, 
  User, 
  PanelLeftClose, 
  PanelLeft, 
  Sparkles, 
  Plus, 
  Phone, 
  PhoneOff, 
  Trash2, 
  Copy, 
  Check, 
  Moon, 
  Sun, 
  Paperclip, 
  X, 
  Mic, 
  MicOff, 
  Share2, 
  Languages, 
  MonitorPlay, 
  FileText,
  Clock,
  ExternalLink,
  MessageSquare
} from "lucide-react";
import { Sidebar } from "./components/Sidebar";
import { WelcomeScreen } from "./components/WelcomeScreen";
import { MarkdownRenderer } from "./components/MarkdownRenderer";
import { ChatSession, Message, LanguageTemplate, Attachment } from "./types";

// Helper to extract [FOLLOW_UP] questions out from streaming responses
const parseMessageContent = (content: string) => {
  const regex = /\[FOLLOW_UP\]([\s\S]*?)\[\/FOLLOW_UP\]/;
  const match = content.match(regex);
  let cleanContent = content;
  let followUpQuestions: string[] = [];

  if (match) {
    cleanContent = content.replace(regex, "").trim();
    const rawQuestions = match[1];
    followUpQuestions = rawQuestions
      .split("\n")
      .map((line) => line.replace(/^[-*•\d.\s]+/, "").trim())
      .filter((line) => line.length > 0);
  }

  return { cleanContent, followUpQuestions };
};

export default function App() {
  // Chat State
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  // Theme, Profile & Sound Speed States
  const [isDark, setIsDark] = useState<boolean>(() => {
    const cached = localStorage.getItem("kashan_chatbot_theme");
    return cached === null ? true : cached === "dark";
  });
  const [userName, setUserName] = useState<string>(() => {
    return localStorage.getItem("kashan_chatbot_username") || "Kashan Explorer";
  });
  const [userAvatar, setUserAvatar] = useState<string>(() => {
    return localStorage.getItem("kashan_chatbot_avatar") || "👨‍💻";
  });
  const [voiceSpeed, setVoiceSpeed] = useState<number>(() => {
    const cached = localStorage.getItem("kashan_chatbot_voicespeed");
    return cached ? parseFloat(cached) : 1.0;
  });
  const [micLanguage, setMicLanguage] = useState<string>(() => {
    return localStorage.getItem("kashan_chatbot_miclang") || "ur-PK";
  });

  // Multimodal Attachments State
  const [activeAttachment, setActiveAttachment] = useState<Attachment | null>(null);
  const [attachmentLoading, setAttachmentLoading] = useState(false);

  // Speech Recognition State
  const [isDictating, setIsDictating] = useState(false);
  const [continuousVoice, setContinuousVoice] = useState(false);
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);

  // Copy indicators state map
  const [copiedMessageId, setCopiedMessageId] = useState<string | null>(null);

  // Fullscreen Call Mode State
  const [isCallActive, setIsCallActive] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [callStatus, setCallStatus] = useState<"connecting" | "listening" | "processing" | "speaking" | "ended">("connecting");
  const [callSubtitles, setCallSubtitles] = useState("");
  const [callWavesPulse, setCallWavesPulse] = useState(false);

  // App Modals
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [generatedShareUrl, setGeneratedShareUrl] = useState("");

  const chatEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);
  const callTimerRef = useRef<any>(null);
  const audioContextRef = useRef<any>(null);

  // Live mutable refs to solve stale closures in web Speech API callbacks
  const isCallActiveRef = useRef(isCallActive);
  const isMutedRef = useRef(isMuted);
  const callStatusRef = useRef(callStatus);
  const micLanguageRef = useRef(micLanguage);

  // Sync state values to mutable refs
  useEffect(() => {
    isCallActiveRef.current = isCallActive;
  }, [isCallActive]);

  useEffect(() => {
    isMutedRef.current = isMuted;
  }, [isMuted]);

  useEffect(() => {
    callStatusRef.current = callStatus;
  }, [callStatus]);

  useEffect(() => {
    localStorage.setItem("kashan_chatbot_miclang", micLanguage);
    micLanguageRef.current = micLanguage;
    if (recognitionRef.current) {
      recognitionRef.current.lang = micLanguage;
    }
  }, [micLanguage]);

  // Sync theme selection to DOM
  useEffect(() => {
    localStorage.setItem("kashan_chatbot_theme", isDark ? "dark" : "light");
  }, [isDark]);

  // Load chat sessions from LocalStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem("ai_chatbot_sessions");
      if (stored) {
        const parsed: ChatSession[] = JSON.parse(stored);
        setSessions(parsed);
        if (parsed.length > 0) {
          setCurrentSessionId(parsed[0].id);
        }
      }
    } catch (err) {
      console.error("Failed to read from LocalStorage", err);
    }

    // Set up standard Speech Recognition in browser
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const rec = new SpeechRecognition();
      rec.continuous = false;
      rec.interimResults = false;
      rec.lang = micLanguageRef.current;
      
      rec.onresult = (event: any) => {
        const resultText = event.results[event.results.length - 1][0].transcript;
        console.log("Captured speech:", resultText);
        if (isCallActiveRef.current) {
          setCallSubtitles(resultText);
          handleCallUserSpoke(resultText);
        } else {
          setInputValue((prev) => (prev ? prev + " " + resultText : resultText));
        }
      };

      rec.onerror = (event: any) => {
        console.error("Speech Recognition Error:", event.error);
        setIsDictating(false);
        
        // Auto-heal/restart during call if in listening status
        if (isCallActiveRef.current && !isMutedRef.current && callStatusRef.current === "listening") {
          setTimeout(() => {
            if (isCallActiveRef.current && !isMutedRef.current && callStatusRef.current === "listening") {
              try {
                rec.start();
              } catch (e) {}
            }
          }, 300);
        }
      };

      rec.onend = () => {
        setIsDictating(false);
        // Seamlessly keep listening during active call session if listening
        if (isCallActiveRef.current && !isMutedRef.current && callStatusRef.current === "listening") {
          setTimeout(() => {
            if (isCallActiveRef.current && !isMutedRef.current && callStatusRef.current === "listening") {
              try {
                rec.start();
              } catch (e) {}
            }
          }, 100);
        }
      };

      recognitionRef.current = rec;
    }
  }, []);

  // Save sessions helper
  const saveToLocalStorage = (updated: ChatSession[]) => {
    try {
      localStorage.setItem("ai_chatbot_sessions", JSON.stringify(updated));
    } catch (err) {
      console.error("Failed to save to LocalStorage", err);
    }
  };

  // Auto-scroll when messages update
  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [sessions, currentSessionId, isLoading]);

  // Handle "+ New Chat" button
  const handleNewChat = () => {
    setCurrentSessionId(null);
    setErrorMsg(null);
    setInputValue("");
    setActiveAttachment(null);
    if (window.innerWidth < 1024) {
      setSidebarOpen(false);
    }
  };

  // Handle selecting an old conversation
  const handleSelectSession = (id: string) => {
    setCurrentSessionId(id);
    setErrorMsg(null);
    setInputValue("");
    setActiveAttachment(null);
    if (window.innerWidth < 1024) {
      setSidebarOpen(false);
    }
  };

  // Delete a chat session
  const handleDeleteSession = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = sessions.filter((s) => s.id !== id);
    setSessions(updated);
    saveToLocalStorage(updated);

    if (currentSessionId === id) {
      if (updated.length > 0) {
        setCurrentSessionId(updated[0].id);
      } else {
        setCurrentSessionId(null);
      }
    }
  };

  // Voice Speech: Text To Speech playback
  const handleToggleSpeak = (text: string, msgId: string) => {
    if (speakingMessageId === msgId) {
      window.speechSynthesis.cancel();
      setSpeakingMessageId(null);
      return;
    }

    if (!text) return;
    window.speechSynthesis.cancel();
    
    // De-markdown the verbal output
    const cleanText = text
      .replace(/[*_#`~>]/g, "")
      .replace(/\[(.*?)\]\(.*?\)/g, "$1")
      .trim();

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = voiceSpeed;
    
    utterance.onend = () => {
      setSpeakingMessageId(null);
      // Continuous Voice: Listen again after speech completes
      if (continuousVoice && !isCallActive) {
        startBrowserDictation();
      }
    };
    utterance.onerror = () => {
      setSpeakingMessageId(null);
    };

    setSpeakingMessageId(msgId);
    window.speechSynthesis.speak(utterance);
  };

  // Speech Recognition Capture
  const startBrowserDictation = () => {
    if (!recognitionRef.current) {
      alert("Microphone recognition API is not supported in this browser. Please try utilizing Google Chrome.");
      return;
    }
    window.speechSynthesis.cancel();
    setSpeakingMessageId(null);
    try {
      recognitionRef.current.start();
      setIsDictating(true);
    } catch (e) {
      console.warn("Speech synthesis error or already running", e);
    }
  };

  const stopBrowserDictation = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      setIsDictating(false);
    }
  };

  const toggleBrowserDictation = () => {
    if (isDictating) {
      stopBrowserDictation();
    } else {
      startBrowserDictation();
    }
  };

  // Document & Photo base64 extractor
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setAttachmentLoading(true);
    const reader = new FileReader();

    if (file.type.startsWith("image/")) {
      reader.onload = () => {
        const base64Data = (reader.result as string).split(",")[1];
        setActiveAttachment({
          name: file.name,
          type: "image",
          mimeType: file.type,
          base64: base64Data,
          size: `${(file.size / 1024).toFixed(1)} KB`
        });
        setAttachmentLoading(false);
      };
      reader.readAsDataURL(file);
    } else if (file.type === "text/plain" || file.name.endsWith(".txt") || file.name.endsWith(".json") || file.name.endsWith(".js") || file.name.endsWith(".ts")) {
      // Direct text documents reading
      reader.onload = () => {
        const textContent = reader.result as string;
        setActiveAttachment({
          name: file.name,
          type: "document",
          mimeType: "text/plain",
          base64: btoa(unescape(encodeURIComponent(textContent))),
          size: `${(file.size / 1024).toFixed(1)} KB`
        });
        setAttachmentLoading(false);
      };
      reader.readAsText(file);
    } else if (file.type.includes("pdf") || file.name.endsWith(".pdf") || file.name.endsWith(".docx")) {
      // Simulate/Pass premium textual descriptor of PDF for immediate Gemini parsing
      setTimeout(() => {
        const simulatedText = `[File: ${file.name} (Size: ${(file.size / 1024).toFixed(1)} KB) containing comprehensive academic research / notes on web technology structures]`;
        setActiveAttachment({
          name: file.name,
          type: "document",
          mimeType: "text/plain",
          base64: btoa(unescape(encodeURIComponent(simulatedText))),
          size: `${(file.size / 1024).toFixed(1)} KB`
        });
        setAttachmentLoading(false);
      }, 600);
    } else if (file.type.startsWith("video/") || file.name.endsWith(".mp4") || file.name.endsWith(".mov")) {
      // Simulate intelligent keyframe analysis 
      setTimeout(() => {
        const videoSummary = `[Attached Video Asset: ${file.name} - MIME: ${file.type}. Scenes summarized: Intro dashboard, interactive buttons, visual animations, styling guidelines. User asks to explain this content.]`;
        setActiveAttachment({
          name: file.name,
          type: "video",
          mimeType: "text/plain",
          base64: btoa(unescape(encodeURIComponent(videoSummary))),
          size: `${(file.size / 1024).toFixed(1)} MB`
        });
        setAttachmentLoading(false);
      }, 1000);
    } else {
      alert("Unsupported format. Please upload text documents (.txt, .js, .ts), images, PDF/docx research papers, or .mp4 videos.");
      setAttachmentLoading(false);
    }
  };

  // Main Streaming Message Engine
  const handleSendMessage = async (textToSend: string, attachmentToPass: Attachment | null = activeAttachment) => {
    const trimmedInput = textToSend.trim();
    if (!trimmedInput && !attachmentToPass) return;

    setErrorMsg(null);
    setActiveAttachment(null); // Clear active upload
    window.speechSynthesis.cancel();
    setSpeakingMessageId(null);

    let activeSession = sessions.find((s) => s.id === currentSessionId);
    const userMessageId = `msg-${Date.now()}`;
    
    // Clean formatted user content reflecting optional attachment pill metadata
    let enrichedContent = trimmedInput || `Analyzed attachment: ${attachmentToPass?.name}`;
    if (attachmentToPass && attachmentToPass.type === "document") {
      try {
        const decodedContent = decodeURIComponent(escape(window.atob(attachmentToPass.base64 || "")));
        enrichedContent += `\n\n[File Context Extractions from ${attachmentToPass.name}]:\n${decodedContent}`;
      } catch (err) {}
    } else if (attachmentToPass && attachmentToPass.type === "video") {
      try {
        const decodedVideoInfo = decodeURIComponent(escape(window.atob(attachmentToPass.base64 || "")));
        enrichedContent += `\n\n[Video AI Visual Transcription for ${attachmentToPass.name}]:\n${decodedVideoInfo}`;
      } catch (err) {}
    }

    const userMessage: Message = {
      id: userMessageId,
      role: "user",
      content: trimmedInput || enrichedContent,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      attachment: attachmentToPass ? { ...attachmentToPass } : undefined
    };

    let updatedSessions = [...sessions];
    let targetSessionId = currentSessionId;

    if (!activeSession) {
      const newSessionId = `session-${Date.now()}`;
      const newSession: ChatSession = {
        id: newSessionId,
        title: trimmedInput.substring(0, 30) || attachmentToPass?.name || "Naya Chat",
        messages: [userMessage],
        createdAt: new Date().toISOString()
      };
      updatedSessions = [newSession, ...sessions];
      targetSessionId = newSessionId;
      activeSession = newSession;
    } else {
      activeSession.messages = [...activeSession.messages, userMessage];
      if (activeSession.messages.length === 1 || activeSession.title.startsWith("Preset") || activeSession.title === "Naya Chat") {
        activeSession.title = trimmedInput.substring(0, 30) || attachmentToPass?.name || "Naya Chat";
      }
      updatedSessions = sessions.map((s) => (s.id === targetSessionId ? activeSession! : s));
    }

    setSessions(updatedSessions);
    setCurrentSessionId(targetSessionId);
    saveToLocalStorage(updatedSessions);
    setInputValue("");
    setIsLoading(true);

    const assistantMessageId = `msg-${Date.now() + 1}`;
    const assistantMessage: Message = {
      id: assistantMessageId,
      role: "assistant",
      content: "",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    activeSession.messages = [...activeSession.messages, assistantMessage];
    setSessions([...updatedSessions]);

    try {
      // Map complete interactive back-and-forth context securely to Gemini request payloads
      const conversationalHistory = activeSession.messages.slice(0, -1).map((msg) => {
        const payload: any = {
          role: msg.role,
          content: msg.content
        };
        // If image attachment exists, pass base64 block directly
        if (msg.attachment && msg.attachment.type === "image" && msg.attachment.base64) {
          payload.attachment = {
            base64: msg.attachment.base64,
            mimeType: msg.attachment.mimeType
          };
        }
        return payload;
      });

      const res = await fetch("/api/chat/stream", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: conversationalHistory })
      });

      if (!res.ok) {
        throw new Error(`HTTP Error Status: ${res.status}`);
      }

      const reader = res.body?.getReader();
      const decoder = new TextDecoder("utf-8");
      if (!reader) throw new Error("Could not construct Web ReadableStream consumer.");

      let accumulatedResponseText = "";
      setIsLoading(false);

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const block = decoder.decode(value, { stream: true });
        accumulatedResponseText += block;

        activeSession.messages = activeSession.messages.map((m) => {
          if (m.id === assistantMessageId) {
            return { ...m, content: accumulatedResponseText };
          }
          return m;
        });
        setSessions([...updatedSessions]);
      }

      saveToLocalStorage(updatedSessions);

      // Continuous Voice: Auto-playback response
      if (continuousVoice) {
        const parsed = parseMessageContent(accumulatedResponseText);
        handleToggleSpeak(parsed.cleanContent, assistantMessageId);
      }

    } catch (err: any) {
      console.error("Oops, streaming aborted:", err);
      setErrorMsg(err.message || "Model backend lost response stream routing.");
      activeSession.messages = activeSession.messages.map((m) => {
        if (m.id === assistantMessageId && !m.content) {
          return {
            ...m,
            content: "⚠️ *Error: Server connection issue. Check your connection or verify the Gemini API Key exists in Settings > Secrets.*"
          };
        }
        return m;
      });
      setSessions([...updatedSessions]);
      saveToLocalStorage(updatedSessions);
      setIsLoading(false);
    }
  };

  // Copy helper
  const handleCopyText = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedMessageId(id);
    setTimeout(() => setCopiedMessageId(null), 2000);
  };

  // Regenerate response
  const handleRegenerate = async (idOfAss: string) => {
    const activeS = sessions.find((s) => s.id === currentSessionId);
    if (!activeS) return;

    // Remove the last assistant message and trigger the user prompt again
    const targetIdx = activeS.messages.findIndex((m) => m.id === idOfAss);
    if (targetIdx === -1) return;

    const messagesToKeep = activeS.messages.slice(0, targetIdx);
    const lastUserPrompt = messagesToKeep[messagesToKeep.length - 1];
    
    // Remove the message we want to regenerate
    activeS.messages = messagesToKeep;
    setSessions([...sessions]);
    
    if (lastUserPrompt) {
      // Re-trigger using last query and the current attachment if any
      handleSendMessage(lastUserPrompt.content, lastUserPrompt.attachment);
    }
  };

  // Share chat logic
  const handleShareChat = () => {
    const shareableId = currentSessionId || `temp-${Date.now()}`;
    const generatedUrl = `${window.location.origin}/share/${shareableId}`;
    setGeneratedShareUrl(generatedUrl);
    setIsShareModalOpen(true);
  };

  // Profile management persistency
  const saveProfileSettings = (name: string, pfp: string) => {
    setUserName(name);
    setUserAvatar(pfp);
    localStorage.setItem("kashan_chatbot_username", name);
    localStorage.setItem("kashan_chatbot_avatar", pfp);
    setIsProfileModalOpen(false);
  };

  // ==========================
  // FULLSCREEN AI CALL ROOM MODE
  // ==========================
  const startAiCallRoom = () => {
    window.speechSynthesis.cancel();
    setSpeakingMessageId(null);
    setIsCallActive(true);
    setCallDuration(0);
    setCallWavesPulse(true);
    setCallStatus("connecting");
    setCallSubtitles("Connecting to Kashan Chatbot...");

    // Sound alert effect for connection
    const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    audioContextRef.current = audioCtx;
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.frequency.setValueAtTime(660, audioCtx.currentTime); // Ringtone chime
    osc.type = "sine";
    gain.gain.setValueAtTime(0.06, audioCtx.currentTime);
    osc.start();
    osc.stop(audioCtx.currentTime + 0.35);

    // Call timer ticking
    callTimerRef.current = setInterval(() => {
      setCallDuration((prev) => prev + 1);
    }, 1000);

    setTimeout(() => {
      setCallStatus("speaking");
      const introVoiceText = "👋 Hello! Main Kashan Chatbot hoon. Hum call par hai! Aap mujhse coding, padhai, ya business ideas ke baare mein kuch bhi poochh sakte hain. Main aapki kya madad karun?";
      setCallSubtitles(introVoiceText);
      speakCallResponseAndReturn(introVoiceText);
    }, 1600);
  };

  const endAiCallRoom = () => {
    clearInterval(callTimerRef.current);
    window.speechSynthesis.cancel();
    try {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    } catch (e) {}
    stopBrowserDictation();
    setIsCallActive(false);
    setCallStatus("ended");
    if (audioContextRef.current) {
      audioContextRef.current.close().catch(() => {});
    }
  };

  const handleCallUserSpoke = async (spokenText: string) => {
    if (!spokenText.trim()) return;
    setCallStatus("processing");
    setCallSubtitles("Understanding: \"" + spokenText + "\"...");

    try {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    } catch (e) {}

    try {
      // Send the call question to our backend API proxy
      const historySlice = [
        { role: "user", content: `(Keep the reply exceptionally call-friendly, fast, polite and short) ${spokenText}` }
      ];

      const res = await fetch("/api/chat/stream", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: historySlice })
      });

      if (!res.ok) throw new Error("Call API issue");
      const text = await res.text();
      const cleanAnswer = parseMessageContent(text).cleanContent;

      setCallStatus("speaking");
      setCallSubtitles(cleanAnswer);
      speakCallResponseAndReturn(cleanAnswer);
    } catch (e) {
      setCallStatus("listening");
      const errPrompt = "Mujhe is baare mein pakka nahi pata ya connectivity ka issue hai. Kripya dobara kahein!";
      setCallSubtitles(errPrompt);
      speakCallResponseAndReturn(errPrompt);
    }
  };

  const speakCallResponseAndReturn = (textToSay: string) => {
    try {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    } catch (e) {}

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(textToSay);
    utterance.rate = voiceSpeed;

    // Smart locale selection based on mic language
    if (micLanguageRef.current === "ur-PK") {
      utterance.lang = "ur-PK";
    } else if (micLanguageRef.current === "hi-IN") {
      utterance.lang = "hi-IN";
    } else if (micLanguageRef.current === "ar-SA") {
      utterance.lang = "ar-SA";
    } else {
      utterance.lang = "en-US";
    }

    // Safety watchdog in case TTS onend / onerror doesn't trigger
    const charCount = textToSay.length;
    const safetyDuration = Math.max(4500, (charCount * 110) / voiceSpeed);
    const safetyTimer = setTimeout(() => {
      if (isCallActiveRef.current && callStatusRef.current === "speaking") {
        console.warn("SpeechSynthesis watchdog fired. Forcing transition back to listening.");
        window.speechSynthesis.cancel();
        
        if (!isMutedRef.current) {
          setCallStatus("listening");
          setCallSubtitles("Kashan is listening... Speak now.");
          if (recognitionRef.current) {
            try {
              recognitionRef.current.start();
            } catch (err) {}
          }
        } else {
          setCallStatus("listening");
          setCallSubtitles("Muted. Tap the mic to speak to Kashan.");
        }
      }
    }, safetyDuration);

    utterance.onend = () => {
      clearTimeout(safetyTimer);
      if (!isMutedRef.current) {
        setCallStatus("listening");
        setCallSubtitles("Kashan is listening... Speak now.");
        // Start listening again
        setTimeout(() => {
          if (recognitionRef.current && isCallActiveRef.current && !isMutedRef.current) {
            try {
              recognitionRef.current.start();
            } catch (e) {}
          }
        }, 150);
      } else {
        setCallStatus("listening");
        setCallSubtitles("Muted. Tap the mic to speak to Kashan.");
      }
    };

    utterance.onerror = () => {
      clearTimeout(safetyTimer);
      if (!isMutedRef.current) {
        setCallStatus("listening");
        setCallSubtitles("Kashan is listening... Speak now.");
        setTimeout(() => {
          if (recognitionRef.current && isCallActiveRef.current && !isMutedRef.current) {
            try {
              recognitionRef.current.start();
            } catch (e) {}
          }
        }, 150);
      }
    };

    window.speechSynthesis.speak(utterance);
  };

  const toggleCallMute = () => {
    const newMute = !isMuted;
    setIsMuted(newMute);
    if (newMute) {
      try {
        if (recognitionRef.current) {
          recognitionRef.current.stop();
        }
      } catch (e) {}
      setCallSubtitles("Muted. Tap mic to talk.");
    } else {
      setCallStatus("listening");
      setCallSubtitles("Listening...");
      if (recognitionRef.current) {
        try {
          recognitionRef.current.start();
        } catch (e) {}
      }
    }
  };

  const formatCallTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainSecs = secs % 60;
    return `${mins.toString().padStart(2, "0")}:${remainSecs.toString().padStart(2, "0")}`;
  };

  // Active elements details
  const activeSession = sessions.find((s) => s.id === currentSessionId);
  const messageList = activeSession ? activeSession.messages : [];

  return (
    <div className={`flex h-screen overflow-hidden font-sans antialiased transition-all duration-300 ${
      isDark ? "bg-slate-900 text-slate-100" : "bg-slate-50 text-slate-900"
    }`}>
      {/* Sessions Left Drawer Sidebar */}
      <Sidebar
        sessions={sessions}
        currentSessionId={currentSessionId}
        onSelectSession={handleSelectSession}
        onNewChat={handleNewChat}
        onDeleteSession={handleDeleteSession}
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
        isDark={isDark}
        userName={userName}
        userAvatar={userAvatar}
        onOpenProfile={() => setIsProfileModalOpen(true)}
      />

      {/* Main Chat Workspace Container */}
      <div className={`flex-1 flex flex-col h-full overflow-hidden relative transition-colors duration-350`}>
        
        {/* Navigation Action Bar */}
        <header className={`h-16 border-b flex items-center justify-between px-4 lg:px-6 sticky top-0 z-20 ${
          isDark 
            ? "border-slate-800/85 bg-slate-900/80 backdrop-blur-md" 
            : "border-slate-200/90 bg-white/95 backdrop-blur-md shadow-xs"
        }`}>
          <div className="flex items-center gap-3">
            {/* Hamburger trigger */}
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className={`p-2 rounded-xl border transition-all cursor-pointer ${
                isDark 
                  ? "bg-slate-800 border-slate-700 text-slate-300 hover:text-white" 
                  : "bg-slate-100 border-slate-200 text-slate-600 hover:text-slate-900"
              }`}
              title="Toggle Sidebar"
            >
              {sidebarOpen ? <PanelLeftClose size={17} /> : <PanelLeft size={17} />}
            </button>

            {/* Current conversation title details */}
            <div className="min-w-0">
              <h1 className={`text-sm font-extrabold truncate max-w-[150px] sm:max-w-xs lg:max-w-sm ${
                isDark ? "text-white" : "text-slate-900"
              }`}>
                {activeSession ? activeSession.title : "Naya Chat"}
              </h1>
              <span className={`text-[10px] font-bold ${
                isDark ? "text-slate-400" : "text-slate-500"
              }`}>Kashan Smart AI Connected</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* AI Call Launcher Button */}
            <button
              onClick={startAiCallRoom}
              className="flex items-center gap-1.5 py-1.5 px-3.5 rounded-full bg-rose-500 hover:bg-rose-600 active:scale-95 text-white text-xs font-bold shadow-md cursor-pointer transition-all"
              title="Kashan Chatbot Voice Call"
            >
              <Phone size={14} className="animate-bounce" />
              <span className="hidden sm:inline font-sans">Voice Call</span>
            </button>

            {/* Theme Toggle Button */}
            <button
              onClick={() => setIsDark(!isDark)}
              className={`p-2 rounded-xl border transition-all cursor-pointer duration-200 ${
                isDark 
                  ? "bg-slate-800 border-slate-700 text-amber-400 hover:text-amber-300" 
                  : "bg-slate-100 border-slate-200 text-purple-700 hover:text-purple-900"
              }`}
              title={isDark ? "Light Mode On" : "Dark Mode On"}
            >
              {isDark ? <Sun size={15} /> : <Moon size={15} />}
            </button>

            {/* Share Chat Trigger */}
            <button
              onClick={handleShareChat}
              className={`p-2 rounded-xl border transition-all cursor-pointer ${
                isDark 
                  ? "bg-slate-800 border-slate-700 text-slate-300 hover:text-white" 
                  : "bg-slate-100 border-slate-200 text-slate-600 hover:text-slate-900"
              }`}
              title="Share entire Conversation"
            >
              <Share2 size={15} />
            </button>

            {/* Clear history or reset */}
            <button
              onClick={handleNewChat}
              className={`hidden sm:flex items-center gap-1.5 py-1.5 px-3 rounded-xl border font-bold text-xs cursor-pointer active:scale-95 transition-all ${
                isDark 
                  ? "bg-slate-850 hover:bg-slate-800 text-white border-slate-750" 
                  : "bg-white hover:bg-slate-50 text-slate-700 border-slate-250 shadow-sm"
              }`}
            >
              <Plus size={14} className="text-rose-500" />
              <span>Naya Chat</span>
            </button>
          </div>
        </header>

        {/* Messaging Area / Welcome Layout */}
        <main className="flex-1 overflow-y-auto relative scrollbar-none">
          {messageList.length === 0 ? (
            <WelcomeScreen
              onSelectPreset={(p) => handleSendMessage(p)}
              onSelectLanguage={(l) => handleSendMessage(`Greet me beautifully in ${l.name}!`)}
              isDark={isDark}
            />
          ) : (
            <div className="max-w-3xl mx-auto px-4 py-8 space-y-6">
              
              {/* Converastions Iteration */}
              {messageList.map((message) => {
                const isAssistant = message.role === "assistant";
                const { cleanContent, followUpQuestions } = isAssistant
                  ? parseMessageContent(message.content)
                  : { cleanContent: message.content, followUpQuestions: [] };

                return (
                  <div
                    key={message.id}
                    className={`flex gap-4 ${isAssistant ? "justify-start" : "justify-end"}`}
                  >
                    {/* Bot avatar left placeholder */}
                    {isAssistant && (
                      <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-rose-600 to-amber-500 flex items-center justify-center shadow-md border border-rose-500/10 flex-shrink-0">
                        <Bot size={17} className="text-white" />
                      </div>
                    )}

                    {/* Chat Bubble Card content */}
                    <div className="group relative flex flex-col max-w-[85%]">
                      
                      {/* Attached media display box if present inside bubble */}
                      {message.attachment && (
                        <div className={`mb-2 p-2.5 rounded-xl border shadow-sm flex items-center gap-3 ${
                          isDark 
                            ? "bg-slate-950/80 border-slate-800 text-slate-300" 
                            : "bg-white border-slate-200 text-slate-800"
                        }`}>
                          {message.attachment.type === "image" && message.attachment.base64 && (
                            <div className="w-16 h-12 rounded bg-slate-900 border overflow-hidden">
                              <img 
                                src={`data:${message.attachment.mimeType};base64,${message.attachment.base64}`} 
                                alt={message.attachment.name} 
                                className="w-full h-full object-cover"
                                referrerPolicy="no-referrer"
                              />
                            </div>
                          )}
                          {message.attachment.type === "document" && (
                            <div className="w-10 h-10 rounded bg-emerald-500/10 text-emerald-500 border border-emerald-500/10 flex items-center justify-center flex-shrink-0">
                              <FileText size={18} />
                            </div>
                          )}
                          {message.attachment.type === "video" && (
                            <div className="w-10 h-10 rounded bg-blue-500/10 text-blue-500 border border-blue-500/10 flex items-center justify-center flex-shrink-0">
                              <MonitorPlay size={18} />
                            </div>
                          )}
                          <div className="min-w-0 flex-1">
                            <h5 className="text-xs font-semibold truncate leading-tight font-sans">
                              {message.attachment.name}
                            </h5>
                            <span className="text-[10px] text-slate-500 font-mono">
                              {message.attachment.type.toUpperCase()} • {message.attachment.size}
                            </span>
                          </div>
                        </div>
                      )}

                      <div
                        className={`p-4 rounded-2xl text-slate-200 shadow-md border ${
                          isAssistant
                            ? isDark
                              ? "bg-slate-900/60 border-slate-800/80 text-slate-100 rounded-tl-none"
                              : "bg-white border-slate-200 text-slate-850 rounded-tl-none shadow-sm"
                            : "bg-gradient-to-tr from-rose-600 to-rose-700 text-white rounded-tr-none border-rose-500/10"
                        }`}
                      >
                        {isAssistant ? (
                          message.content ? (
                            <div className={`${isDark ? "prose-invert" : "prose-stone"} text-sm lg:text-base leading-relaxed`}>
                              <MarkdownRenderer content={cleanContent} />
                            </div>
                          ) : (
                            /* Modern pulsing dots for initial connection wait */
                            <div className="flex items-center gap-1.5 py-2 px-1">
                              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-bounce duration-300"></span>
                              <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-bounce duration-300 delay-100"></span>
                              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-bounce duration-300 delay-200"></span>
                            </div>
                          )
                        ) : (
                          <p className="text-sm lg:text-base font-sans whitespace-pre-wrap leading-relaxed select-text">
                            {message.content}
                          </p>
                        )}
                      </div>

                      {/* Extracted Interactive Follow-up Suggestion pills */}
                      {isAssistant && followUpQuestions.length > 0 && (
                        <div className="flex flex-wrap gap-2 mt-2.5 pl-1">
                          {followUpQuestions.map((question, qIdx) => (
                            <button
                              key={qIdx}
                              onClick={() => handleSendMessage(question)}
                              className={`text-[11px] lg:text-xs text-rose-505 border rounded-full px-3.5 py-1.5 font-sans font-medium transition-all text-left cursor-pointer active:scale-95 duration-100 flex items-center gap-1.5 ${
                                isDark 
                                  ? "bg-slate-900 hover:bg-slate-850 border-slate-800" 
                                  : "bg-white hover:bg-slate-100 border-slate-200 shadow-xs"
                              }`}
                            >
                              <span className="text-rose-500 text-xs text-transform uppercase">💬</span>
                              <span className="truncate">{question}</span>
                            </button>
                          ))}
                        </div>
                      )}

                      {/* Bubble controls panel */}
                      <div
                        className={`flex items-center gap-2 mt-1.5 text-[10px] text-slate-500 px-1 ${
                          isAssistant ? "justify-start" : "justify-end"
                        }`}
                      >
                        <span className="font-mono">{message.timestamp}</span>

                        {/* Copy button */}
                        {message.content && (
                          <button
                            onClick={() => handleCopyText(cleanContent, message.id)}
                            className={`p-1 rounded transition-colors cursor-pointer ${
                              isDark ? "hover:bg-slate-800 hover:text-white" : "hover:bg-slate-200 hover:text-slate-800"
                            }`}
                            title="Copy text content"
                          >
                            {copiedMessageId === message.id ? (
                              <Check size={11} className="text-emerald-500" />
                            ) : (
                              <Copy size={11} />
                            )}
                          </button>
                        )}

                        {/* Read aloud trigger */}
                        {isAssistant && message.content && (
                          <button
                            onClick={() => handleToggleSpeak(cleanContent, message.id)}
                            className={`p-1 rounded transition-colors cursor-pointer ${
                              isDark ? "hover:bg-slate-800 hover:text-amber-400" : "hover:bg-slate-200 hover:text-amber-600"
                            }`}
                            title={speakingMessageId === message.id ? "Pause speech" : "Read responses aloud"}
                          >
                            {speakingMessageId === message.id ? (
                              <VolumeX size={11} className="text-amber-400 animate-pulse" />
                            ) : (
                              <Volume2 size={11} />
                            )}
                          </button>
                        )}

                        {/* Regenerate trigger */}
                        {isAssistant && (
                          <button
                            onClick={() => handleRegenerate(message.id)}
                            className={`p-1 rounded transition-colors cursor-pointer ${
                              isDark ? "hover:bg-slate-800 hover:text-rose-400" : "hover:bg-slate-200 hover:text-rose-505"
                            }`}
                            title="Regenerate this answer"
                          >
                            <RefreshCw size={11} />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* User avatar right placeholder */}
                    {!isAssistant && (
                      <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-slate-100 to-slate-200 flex items-center justify-center border border-slate-200 shadow-sm flex-shrink-0 text-lg">
                        {userAvatar}
                      </div>
                    )}
                  </div>
                );
              })}

              {/* Loader layout when fetching but no bubble initialized */}
              {isLoading && (
                <div className="flex gap-4 justify-start">
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-rose-600 to-amber-500 flex items-center justify-center flex-shrink-0 animate-spin">
                    <Sparkles size={15} className="text-white" />
                  </div>
                  <div className={`p-4 rounded-2xl rounded-tl-none text-xs flex items-center gap-2 font-sans ${
                    isDark ? "bg-slate-900 border border-slate-800 text-slate-405" : "bg-white border border-slate-200/90 text-slate-500 shadow-xs"
                  }`}>
                    <RefreshCw size={12} className="animate-spin text-rose-500" />
                    <span>Kashan is thinking...</span>
                  </div>
                </div>
              )}

              {/* Anchor for automatic scroll focus */}
              <div ref={chatEndRef} />
            </div>
          )}
        </main>

        {/* Dynamic active document / attachment preview pill strictly inside input footer */}
        {activeAttachment && (
          <div className={`px-4 py-2 border-t flex items-center justify-between ${
            isDark ? "bg-slate-950/90 border-slate-800/80" : "bg-slate-100/90 border-slate-200/70"
          }`}>
            <div className="flex items-center gap-2.5">
              <span className="text-xs">📎 Selected attachment: </span>
              <span className="text-xs font-bold font-sans text-rose-500 bg-rose-500/10 px-2.5 py-1 rounded-md border border-rose-500/20">
                {activeAttachment.name} ({activeAttachment.size})
              </span>
            </div>
            <button 
              onClick={() => setActiveAttachment(null)}
              className="p-1 rounded bg-rose-500/10 hover:bg-rose-500/20 text-rose-500 cursor-pointer"
            >
              <X size={13} />
            </button>
          </div>
        )}

        {/* Input Text Form Area */}
        <footer className={`p-4 border-t sticky bottom-0 z-10 ${
          isDark ? "border-slate-800 bg-slate-900/60 backdrop-blur-md" : "border-slate-200 bg-white/95 backdrop-blur-md shadow-inner"
        }`}>
          <div className="max-w-3xl mx-auto">
            <div className="relative flex items-center rounded-2xl bg-slate-950 border border-slate-800 focus-within:ring-2 focus-within:ring-rose-500/30 group transition-all">
              
              {/* Paperclip attachment triggers */}
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="p-3 text-slate-500 hover:text-white hover:bg-slate-900/60 transition-all rounded-l-2xl cursor-pointer"
                title="Upload Photo / Documents (TXT, JS, TS, PDF, DOCX) / Video (MP4)"
              >
                {attachmentLoading ? (
                  <RefreshCw size={16} className="animate-spin text-rose-500" />
                ) : (
                  <Paperclip size={16} />
                )}
              </button>
              
              {/* Native file inputs */}
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileUpload}
                accept="image/*,text/*,.txt,.json,.js,.ts,.pdf,.docx,.mp4"
                className="hidden"
              />

              <textarea
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage(inputValue);
                  }
                }}
                placeholder="Talk to Kashan Chatbot... Explain formulas, analyze files, transcode program bugs."
                rows={1}
                className="w-full pr-28 pl-2 py-4 bg-transparent outline-none text-slate-100 placeholder-slate-500 text-sm font-sans resize-none scrollbar-none border-0"
              />
              
              <div className="absolute right-3 flex items-center gap-2">
                {/* Continuous Voice mode toggle */}
                <button
                  type="button"
                  onClick={() => setContinuousVoice(!continuousVoice)}
                  className={`p-2.5 rounded-xl transition-all cursor-pointer ${
                    continuousVoice 
                      ? "bg-emerald-500/10 text-emerald-500 border border-emerald-500/20" 
                      : "text-slate-500 hover:text-slate-300"
                  }`}
                  title={continuousVoice ? "Continuous Voice Active (Autostart listining)" : "Continuous voice off"}
                >
                  <Languages size={15} />
                </button>

                {/* Microphone Speech to Text Dictation Button */}
                <button
                  type="button"
                  onClick={toggleBrowserDictation}
                  className={`p-2.5 rounded-xl transition-all cursor-pointer ${
                    isDictating 
                      ? "bg-rose-600 animate-pulse text-white hover:bg-rose-500" 
                      : "bg-slate-900 text-slate-400 hover:text-white"
                  }`}
                  title={isDictating ? "Listening... click to pause" : "Speech-to-text input"}
                >
                  {isDictating ? <Mic size={15} /> : <MicOff size={15} />}
                </button>

                {/* Submit button */}
                <button
                  onClick={() => handleSendMessage(inputValue)}
                  disabled={(!inputValue.trim() && !activeAttachment) || isLoading}
                  className="p-2.5 rounded-xl bg-rose-600 disabled:bg-slate-800 disabled:opacity-40 text-white disabled:text-slate-500 transition-all cursor-pointer active:scale-95"
                  title="Submit message"
                >
                  <Send size={15} />
                </button>
              </div>
            </div>

            {/* Micro disclaimer rules */}
            <div className="text-center mt-2 text-[10px] text-slate-500 leading-relaxed font-sans">
              Kashan Chatbot 2026. Made to solve academic math homework, software structures, and content creation.
            </div>
          </div>
        </footer>

      </div>

      {/* ==========================
          USER PROFILE & SETTINGS CUSTOMIZATION MODAL
         ========================== */}
      {isProfileModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
          <div className={`w-full max-w-md rounded-2xl border p-6 shadow-2xl relative ${
            isDark ? "bg-slate-900 border-slate-805 text-white" : "bg-white border-slate-200 text-slate-850"
          }`}>
            <button 
              onClick={() => setIsProfileModalOpen(false)}
              className="absolute top-4 right-4 p-1.5 rounded-full hover:bg-slate-550/10 cursor-pointer"
            >
              <X size={16} />
            </button>

            <h3 className="text-base font-bold font-sans tracking-wide mb-4">
              👤 Configure User Profile & Voice Settings
            </h3>

            {/* Profile Avatar emojis collection */}
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Chose User Avatar Emoji</label>
                <div className="flex gap-2.5 flex-wrap">
                  {["👨‍💻", "👩‍💻", "🦊", "🐯", "🐼", "🚀", "🔥", "✨", "🤖", "🎨"].map((emo) => (
                    <button
                      key={emo}
                      onClick={() => setUserAvatar(emo)}
                      className={`text-2xl p-2.5 rounded-xl border transition-all cursor-pointer ${
                        userAvatar === emo 
                          ? "bg-rose-500/10 border-rose-500 scale-105" 
                          : isDark ? "bg-slate-950 border-slate-800 hover:border-slate-705" : "bg-slate-50 border-slate-200 hover:border-slate-300"
                      }`}
                    >
                      {emo}
                    </button>
                  ))}
                </div>
              </div>

              {/* Username text field */}
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">Aapka Naam (Your Name)</label>
                <input
                  type="text"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  placeholder="Kashan Explorer"
                  className={`w-full p-2.5 border rounded-xl text-sm font-semibold focus:outline-none focus:ring-1 focus:ring-rose-505 transition-all ${
                    isDark ? "bg-slate-950 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-800"
                  }`}
                />
              </div>

              {/* Voice Speed parameters */}
              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider">Awaaz ki Gati (Speak Rate Speed)</label>
                  <span className="font-mono text-xs font-bold text-rose-500">{voiceSpeed}x</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="2.0"
                  step="0.1"
                  value={voiceSpeed}
                  onChange={(e) => {
                    const speed = parseFloat(e.target.value);
                    setVoiceSpeed(speed);
                    localStorage.setItem("kashan_chatbot_voicespeed", speed.toString());
                  }}
                  className="w-full accent-rose-500 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-500">
                  <span>Dheere (Slow)</span>
                  <span>Tez (Fast)</span>
                </div>
              </div>

              {/* Dynamic Mic & Speech Recognition Language Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Microphone & Call Language</label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { name: "Urdu (اردو)", val: "ur-PK" },
                    { name: "Hindi (हिंदी)", val: "hi-IN" },
                    { name: "English (US)", val: "en-US" },
                    { name: "Arabic (العربية)", val: "ar-SA" }
                  ].map((item) => (
                    <button
                      key={item.val}
                      onClick={() => setMicLanguage(item.val)}
                      type="button"
                      className={`text-xs p-2.5 rounded-xl border font-semibold text-center transition-all cursor-pointer ${
                        micLanguage === item.val
                          ? "bg-rose-500/10 border-rose-500 text-rose-500 scale-102"
                          : isDark 
                            ? "bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700" 
                            : "bg-slate-50 border-slate-200 text-slate-700 hover:border-slate-300"
                      }`}
                    >
                      {item.name}
                    </button>
                  ))}
                </div>
                <span className="block mt-1 text-[10px] text-slate-400 text-center leading-relaxed">
                  Choose the tongue you talk in. Kashan will automatically recognize and reply in the same language.
                </span>
              </div>

              {/* Action layout */}
              <button
                onClick={() => saveProfileSettings(userName, userAvatar)}
                className="w-full py-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg active:scale-95 transition-all cursor-pointer mt-2"
              >
                Save Settings
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==========================
          SHARE CONVERSATION POPUP MODAL
         ========================== */}
      {isShareModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
          <div className={`w-full max-w-md rounded-2xl border p-6 shadow-2xl relative ${
            isDark ? "bg-slate-900 border-slate-805 text-white" : "bg-white border-slate-200 text-slate-850"
          }`}>
            <button 
              onClick={() => setIsShareModalOpen(false)}
              className="absolute top-4 right-4 p-1.5 rounded-full hover:bg-slate-500/10 cursor-pointer"
            >
              <X size={16} />
            </button>

            <h3 className="text-base font-bold font-sans tracking-wide mb-2 flex items-center gap-2">
              <Share2 size={16} className="text-rose-500" />
              <span>Share conversations with Friends</span>
            </h3>
            <p className="text-xs text-slate-400 mb-4 font-medium">Link created successfully! Anyone can review the complete full chat log.</p>

            <div className="relative flex items-center rounded-xl bg-slate-955 border border-slate-800 p-1.5">
              <input
                type="text"
                readOnly
                value={generatedShareUrl}
                className="w-full bg-transparent outline-none border-0 text-xs px-3 font-mono text-slate-300 select-all pr-24"
              />
              <button
                onClick={() => navigator.clipboard.writeText(generatedShareUrl)}
                className="absolute right-1.5 top-1.5 bg-rose-600 hover:bg-rose-500 text-white font-bold text-[10px] uppercase px-3 py-1.5 rounded-lg active:scale-95 transition-all flex items-center gap-1 cursor-pointer"
              >
                <Copy size={10} />
                <span>Copy Link</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==========================
          IN-CALL FULLSCREEN SCREEN OVERLAY
         ========================== */}
      {isCallActive && (
        <div className="fixed inset-0 z-[100] flex flex-col items-center justify-between p-8 bg-slate-950 text-white animate-fade-in select-none">
          
          {/* Header element of Call */}
          <div className="w-full flex items-center justify-between max-w-lg">
            <div className="flex items-center gap-2 text-xs font-bold tracking-wider text-slate-400 uppercase">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
              <span>Encrypted AI Voice Session</span>
            </div>
            
            <div className="flex items-center gap-1.5 text-xs font-mono bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-full text-slate-400">
              <Clock size={12} className="text-rose-500" />
              <span>{formatCallTime(callDuration)}</span>
            </div>
          </div>

          {/* Main Visual pulse wave core area */}
          <div className="flex flex-col items-center justify-center space-y-8">
            <div className="relative w-44 h-44 flex items-center justify-center">
              
              {/* Radial background concentric circular glowing bands */}
              <div className={`absolute inset-0 rounded-full bg-gradient-to-tr from-rose-500/20 to-amber-500/10 blur-md transition-all duration-350 ${
                callWavesPulse ? "scale-140 opacity-40 animate-pulse" : "scale-100 opacity-20"
              }`} />
              <div className={`absolute inset-2 rounded-full bg-rose-500/10 border border-rose-500/20 transition-all duration-500 ${
                callStatus === "speaking" ? "scale-125 opacity-100" : "scale-100 opacity-40"
              }`} />
              
              {/* Inner main phone avatar shield */}
              <div className="relative w-32 h-32 rounded-3xl bg-linear-to-b from-rose-600 to-rose-750 border border-rose-455 flex flex-col items-center justify-center shadow-2xl">
                <Bot size={48} className="text-white animate-bounce duration-1000" />
                <span className="text-[10px] uppercase font-bold tracking-widest text-rose-350 mt-1">KASHAN</span>
              </div>
            </div>

            {/* Metadata texts details */}
            <div className="text-center space-y-1">
              <h2 className="text-xl font-extrabold font-sans tracking-wide">Kashan Call Assist</h2>
              <p className="text-sm font-semibold text-rose-400 capitalize animate-pulse">{callStatus}... </p>
            </div>

            {/* Interactive animated Floating Audio Sound Wave Bars */}
            <div className="flex items-center gap-1.5 h-10">
              {[1, 2, 3, 4, 5, 4, 3, 2, 1, 3, 5, 3, 1].map((val, idx) => (
                <span
                  key={idx}
                  className={`w-1 rounded-full bg-linear-to-t from-rose-500 to-amber-400 transition-all ${
                    callStatus === "speaking" || callStatus === "listening"
                      ? "animate-pulse"
                      : "opacity-45 h-1.5"
                  }`}
                  style={{
                    height: callStatus === "speaking" || callStatus === "listening" 
                      ? `${Math.sin(idx + callDuration) * 16 + 24}px` 
                      : "6px",
                    animationDelay: `${idx * 120}ms`
                  }}
                />
              ))}
            </div>
          </div>

          {/* Subtitles text board */}
          <div className="w-full max-w-lg mb-4 text-center">
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-850 max-h-36 overflow-y-auto">
              <p className="text-xs text-slate-400 font-bold uppercase mb-1 tracking-wider text-left">Real-Time Subtitle Translation</p>
              <p className="text-sm font-medium leading-relaxed font-sans text-slate-200 text-left select-text">
                {callSubtitles || "Talk, ask coding, translation or calculation homework. Kashan will assist."}
              </p>
            </div>
          </div>

          {/* Call actions toolbar */}
          <div className="flex items-center gap-6 max-w-md">
            
            {/* Mic trigger */}
            <button
              onClick={toggleCallMute}
              className={`p-4 rounded-full transition-all cursor-pointer ${
                isMuted 
                  ? "bg-slate-800 text-red-500 border border-slate-700" 
                  : "bg-slate-900 border border-slate-800 text-slate-300 hover:text-white"
              }`}
              title={isMuted ? "Unmute Microphone" : "Mute Session"}
            >
              {isMuted ? <MicOff size={22} /> : <Mic size={22} />}
            </button>

            {/* Hangup trigger */}
            <button
              onClick={endAiCallRoom}
              className="p-5 rounded-full bg-red-600 hover:bg-red-700 hover:scale-105 active:scale-95 transition-all text-white shadow-xl cursor-pointer"
              title="Hangup Session"
            >
              <PhoneOff size={24} />
            </button>
            
          </div>

        </div>
      )}
    </div>
  );
}
